import React from 'react';
import './App.css';

import Word from './components/Word'

function App() {
  return (
    <main>
      <Word/>
    </main>
  );
}

export default App;
